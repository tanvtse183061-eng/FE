export default function Vinfastxanh(){
    return(
        <h1>

        </h1>
    )
}